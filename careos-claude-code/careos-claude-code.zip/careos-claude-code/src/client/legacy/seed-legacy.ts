import { Surreal } from 'surrealdb.js';

async function seed() {
  console.log("Connecting to SurrealDB...");
  const db = new Surreal();
  
  try {
    await db.connect('http://localhost:8000/rpc');
    await db.signin({
      user: 'root',
      pass: 'root',
    });
    await db.use({ namespace: 'coopcare', database: 'operational' });

    console.log("Seeding Users...");
    
    // Lisa (Conductor)
    const lisa = await db.create('user', {
      email: 'lisa@example.com',
      firstName: 'Lisa',
      lastName: 'Chen',
      role: 'conductor',
      zipCode: '80202', // Denver
      isActive: true,
      createdAt: new Date(),
    });

    // Janet (Time Bank Neighbor)
    const janet = await db.create('user', {
      email: 'janet@example.com',
      firstName: 'Janet',
      lastName: 'R.',
      role: 'timebank_member',
      zipCode: '80304', // Boulder
      isActive: true,
      createdAt: new Date(),
    });

    // Patricia (Employer HR)
    const patricia = await db.create('user', {
      email: 'patricia@bvsd.org',
      firstName: 'Patricia',
      lastName: 'Valderrama',
      role: 'employer_hr',
      zipCode: '80301',
      isActive: true,
      createdAt: new Date(),
    });

    console.log("Seeding Care Recipient...");
    const mom = await db.create('care_recipient', {
      firstName: 'Margaret',
      lastName: 'Chen',
      dateOfBirth: new Date('1945-05-12'),
      primaryDiagnoses: ['I50.9', 'E11.9', 'F03.90'],
      mobilityLevel: 'assisted',
      cognitiveStatus: 'mild_impairment',
      wearableConnected: true,
    });

    console.log("Seeding Family...");
    const family = await db.create('family', {
      name: 'Chen Family',
      membershipStatus: 'active',
      primaryConductor: lisa[0].id,
      careRecipient: mom[0].id,
    });

    console.log("Seeding Time Bank Account...");
    await db.create('time_bank_account', {
      family: family[0].id,
      balanceEarned: 12.5,
      balanceMembership: 40,
      balanceBought: 0,
      balanceDeficit: 0,
      lifetimeEarned: 15,
      lifetimeSpent: 2.5,
      impactScore: 148,
      currentStreak: 4,
    });

    console.log("Seeding Omaha Assessments...");
    await db.create('omaha_assessment', {
      family: family[0].id,
      problem: '21 Cognition',
      kbs_knowledge: 3,
      kbs_behavior: 4,
      kbs_status: 3,
      assessedAt: new Date(),
    });

    console.log("Seeding Conductor Certifications...");
    await db.create('conductor_cert', {
      user: lisa[0].id,
      module: 'Safe Transfers',
      completedAt: new Date(),
      tbHoursEarned: 5,
    });

    console.log("Seeding Referrals...");
    await db.create('referral', {
      referrer: lisa[0].id,
      referredEmail: 'karen@example.com',
      status: 'converted',
      tbBonusAwarded: true,
    });

    console.log("Seeding Graph Edges...");
    await db.query(`
      RELATE $janet->helped->$lisa SET task = 'Meals Delivered', hours = 1.5, date = time::now();
      RELATE $lisa->member_of->$coop SET joined = time::now();
    `, {
      janet: janet[0].id,
      lisa: lisa[0].id,
      coop: 'cooperative:main'
    });

    console.log("Seed complete!");
  } catch (err) {
    console.error("Seed failed:", err);
  } finally {
    await db.close();
  }
}

seed();
