# CareOS — Claude Code Build Instructions

## What This Is

CareOS is the operating system for co-op.care, a worker-owned home care cooperative in Boulder, Colorado. You are building a HIPAA-compliant, mobile-first PWA backed by SurrealDB (operations) + Aidbox FHIR R4 (clinical) + Redis (cache/pub-sub).

**Read `docs/PRD.md` for the full product requirements. Read `docs/ARCHITECTURE.md` for the detailed module specs, data models, API endpoints, and file creation plan.**

## Critical Context

- **Primary user:** The Conductor (Alpha Daughter, female 35-60, manages aging parent's care from her phone)
- **Medical Director:** Josh Emdur, DO — signs all LMNs, conducts CRI assessments
- **Clinical taxonomy:** Omaha System (42 problems, 4 domains) — this is the entire clinical backbone
- **Founder:** Blaine Warkentine, MD — blaine@co-op.care

## Tech Stack (Non-Negotiable)

| Layer | Technology | Version |
|-------|-----------|---------|
| Frontend | React + TypeScript | 19.x |
| Build | Vite + vite-plugin-pwa | 6.4.x |
| CSS (new features) | Tailwind CSS | 4.x |
| CSS (legacy suite) | Inline styles | DO NOT CHANGE |
| Backend | Fastify (modular monolith) | 5.x |
| Runtime | Node.js LTS | 22.x |
| Operational DB | SurrealDB | 3.0+ |
| Clinical DB | Health Samurai Aidbox (FHIR R4) | Latest |
| Cache/Pub-Sub | Redis | 7.x |
| Charts | Recharts | 2.x |
| Testing | Vitest (unit), Playwright (E2E) | Latest |

## Brand System

- **Fonts:** Literata (serif, headings) + DM Sans (sans-serif, body)
- **Colors:** Sage #4F7A5E (primary), Copper #B07A4F (Conductor), Gold #C49B40 (financial), Blue #4A6FA5 (institutional), Purple #7A5CB8 (federal)

## Build Order — Phase 1 (Build This First)

Build in this exact sequence. Each step depends on the prior step.

### Step 1: Project Scaffold
- Initialize Vite + React 19 + TypeScript project
- Configure Tailwind CSS 4 with brand tokens
- Configure vite-plugin-pwa (manifest, service worker, offline fallback)
- Set up monorepo paths: `src/client/`, `src/server/`, `src/shared/`
- Create `docker-compose.yml` (SurrealDB 3.0 + Redis 7 + Aidbox + PostgreSQL)
- Create `.env.example` with all required env vars
- Create `package.json` with all dependencies
- Set up ESLint + Prettier
- Create `.github/workflows/ci.yml`

### Step 2: Shared Constants and Types
- `src/shared/constants/omaha-system.ts` — all 42 problems, 4 domains, intervention categories
- `src/shared/constants/icd10-crosswalk.ts` — default Omaha ↔ ICD-10 mappings
- `src/shared/constants/business-rules.ts` — CII zones, Time Bank limits, pricing, GPS radius
- `src/shared/constants/loinc-codes.ts` — wearable vitals LOINC codes
- `src/shared/constants/irs-pub502.ts` — IRS Publication 502 categories
- `src/shared/types/*.types.ts` — all TypeScript interfaces (see ARCHITECTURE.md §0.4.2)

### Step 3: Backend Foundation
- `src/server/app.ts` — Fastify app factory with plugin registration
- `src/server/server.ts` — entry point with graceful shutdown
- `src/server/database/surrealdb.ts` — SurrealDB connection + schema init
- `src/server/database/surrealdb.schema.surql` — all table definitions, indexes, graph edges, geospatial indexes
- `src/server/database/aidbox.ts` — Aidbox FHIR R4 REST client
- `src/server/database/redis.ts` — Redis client with pooling
- `src/server/middleware/auth.middleware.ts` — JWT RS256 verification + role extraction
- `src/server/middleware/audit.middleware.ts` — PHI access audit logging
- `src/server/middleware/rate-limit.middleware.ts`
- `src/server/middleware/error-handler.middleware.ts` — HIPAA-safe (no PHI in errors)
- `src/server/common/constants.ts`, `exceptions.ts`, `logger.ts`, `validators.ts`

### Step 4: Auth Module
- `src/server/modules/auth/` — plugin, routes, service, schemas, guards
- JWT RS256 with 15-min access / 7-day refresh tokens
- 7-role RBAC: conductor, worker_owner, timebank_member, medical_director, admin, employer_hr, wellness_provider
- Multi-role per user support
- Optional 2FA (mandatory for medical_director and admin)

### Step 5: Family Module
- `src/server/modules/family/` — CRUD for Family + CareRecipient
- Stripe $100/year membership integration
- Care team graph relationships in SurrealDB

### Step 6: Assessment Engine
- `src/server/modules/assessments/` — CII + Mini CII + CRI
- CII: 12 dimensions, scored 1-10 via sliders, total /120
- Zones: Green ≤40, Yellow 41-79, Red ≥80
- Mini CII: 3 sliders (physical, sleep, isolation), /30
- Mini zones: Green ≤11, Yellow 12-20, Red ≥21
- CRI: 14 factors, min 14.4, max 72.0, MD review workflow
- Store in SurrealDB (operational) + sync to Aidbox (QuestionnaireResponse)

### Step 7: Time Bank Engine
- `src/server/modules/timebank/` — the most complex module
- Double-entry credit ledger (earned, spent, bought, donated, expired, deficit)
- Skill/proximity matching: identity-matched 2×, <0.5mi 3×, 0.5-1mi 2×, 1-2mi 1×, >2mi remote only
- GPS verification: check-in/check-out within 0.25 miles (Haversine)
- Respite Default: 0.9 hrs to member + 0.1 hrs to Respite Fund (opt-out-able, genuinely easy)
- $15/hr cash purchase: $12 coordination + $3 Respite Fund
- 40 hr/year membership floor, -20 hr deficit max
- 12-month graduated expiry → auto-donate to Respite
- Behavioral nudges at -5/-10/-15/-20 deficit
- Streak tracking (4/8/12/26/52 weeks)
- Omaha auto-coding (see task map below)
- Cascade visualization via SurrealDB graph queries

### Step 8: FHIR Sync Service
- `src/server/modules/fhir-sync/` — async SurrealDB → Aidbox sync
- Redis-backed job queue with exponential backoff retry
- Sync Encounters, Observations, QuestionnaireResponses

### Step 9: Notification Engine
- `src/server/modules/notifications/` — push, SMS, email, in-app
- Twilio (SMS), SendGrid (email), Web Push API
- 8 notification categories per ARCHITECTURE.md

### Step 10: Frontend — Conductor Dashboard
- `src/client/features/conductor/` — real-time care timeline
- WebSocket connection to SurrealDB live queries
- Time Bank balance widget (6-field breakdown)
- Push notifications
- Secure messaging

### Step 11: Frontend — Assessments
- `src/client/features/assessments/` — CII slider interface (warm, NOT clinical)
- Mini CII Quick Check (completable in 30 seconds)
- Zone visualization with color coding

### Step 12: Frontend — Time Bank Hub
- `src/client/features/timebank/` — task cards, accept flow, GPS check-in/out
- Gratitude prompts, cascade visualization, streak counter

### Step 13: Onboarding Flow
- Mini CII → account creation → full CII → Stripe payment → CRI scheduling → dashboard
- Target: <10 minutes end-to-end

### Step 14: Public Website Integration
- Mount legacy components from `src/client/legacy/` at public routes
- These use inline styles — DO NOT apply Tailwind to them
- New CareOS features behind auth wall use Tailwind

### Step 15: Aidbox Init Bundle
- `config/aidbox/omaha-codesystem.json` — 42 problems, 4 domains
- `config/aidbox/cii-questionnaire.json`
- `config/aidbox/cri-questionnaire.json`
- `config/aidbox/omaha-to-icd10-conceptmap.json`
- `config/aidbox/icd10-to-omaha-conceptmap.json`

### Step 16: Background Jobs
- `src/server/jobs/timebank-expiry.job.ts` — 12-month credit expiry
- `src/server/jobs/membership-renewal.job.ts` — annual 40-hour floor reset
- `src/server/jobs/lmn-renewal.job.ts` — 60/30/7 day reminders
- `src/server/jobs/kbs-reassessment.job.ts` — 30/60/90 day scheduling

### Step 17: Tests
- Unit tests for: CII zone classification, Time Bank ledger, matching algorithm, Omaha auto-coding, GPS verification, Respite Default split, deficit enforcement
- Integration tests for SurrealDB ↔ Aidbox sync
- E2E: Conductor onboarding, Time Bank exchange

## Omaha System Auto-Coding Map (IMMUTABLE)

Every Time Bank task maps to an Omaha problem:

| Task Type | Omaha Problem | Code | Intervention Category |
|-----------|--------------|------|-----------------------|
| meals | Digestion-Hydration | #28 | Treatments/Procedures |
| rides | Communication w/ Community Resources | #05 | Case Management |
| companionship | Social Contact | #06 | Surveillance |
| phone_companionship | Social Contact | #06 | Surveillance |
| tech_support | Communication w/ Community Resources | #05 | Teaching/Guidance |
| yard_work | Residence | #03 | Treatments/Procedures |
| housekeeping | Sanitation | #02 | Treatments/Procedures |
| grocery_run | Digestion-Hydration | #28 | Case Management |
| errands | Communication w/ Community Resources | #05 | Case Management |
| pet_care | Social Contact | #06 | Surveillance |
| admin_help | Communication w/ Community Resources | #05 | Case Management |
| teaching | Varies by subject | — | Teaching/Guidance/Counseling |

## Key Numbers (IMMUTABLE — do not change these)

| Metric | Value |
|--------|-------|
| US family caregivers | 63M |
| Weekly unpaid care | 27 hours |
| Out-of-pocket per caregiver | $7,200/year |
| Agency turnover | 77% |
| BVSD teachers | 1,717 (NOT 6,000) |
| TRU PACE enrollees | 341 |
| BCH readmission rate | 15.4% |
| Average readmission cost | $16,037 |
| Private pay rate | $35/hr |
| Worker-owner wage | $25-28/hr + equity (~$52K/5yr) |
| Time Bank cash rate | $15/hr ($12 coord + $3 Respite) |
| Time Bank floor | 40 hrs/year (in $100 membership) |
| HSA/FSA savings via LMN | 28-36% |
| CII dimensions | 12, scored 1-10, total /120 |
| CRI range | min 14.4, max 72.0 |
| KBS subscales | K 1-5, B 1-5, S 1-5 |
| Omaha System problems | 42 across 4 domains |

## Anti-Patterns (DO NOT BUILD)

1. NO marketplace where families browse/hire caregivers — matching is algorithmic
2. NO separate apps per user type — ONE app with role-based views
3. NO real-time video calling — Zoom API integration only
4. NO insurance claims engine — Age at Home is 2028+
5. NO drag-and-drop scheduling — coordinator assigns, worker confirms
6. NO long Time Bank onboarding gate — first interaction within 24 hours
7. NO clinical-feeling CII — warm, conversational, slider-based
8. NO gamification (points/levels/badges/leaderboards) — streaks + impact scores only
9. NO dark patterns for Respite Default — opt-out must be genuinely easy
10. NO storage of SSNs/full card numbers/bank accounts — Stripe and Checkr handle PII

## Coding Conventions

- TypeScript strict mode, no `any` in business logic
- Fastify plugin pattern for each module (see ARCHITECTURE.md §0.9.1)
- TypeBox for request/response schema validation
- No PHI in logs, error messages, or client-side storage
- SurrealDB: parameterized SurrealQL queries (prevent injection)
- Graph edges: `helped`, `member_of`, `assigned_to`, `cascaded_to`, `refers_to`
- Dual-database write: SurrealDB first (sync), then Aidbox via Redis job queue (async)
- All FHIR resource access logged as AuditEvent in Aidbox

## File Structure Reference

See `docs/ARCHITECTURE.md` section 0.5.1 for the complete repo structure.

## Phase 2 (Build After Phase 1 is Deployed)

After Phase 1 is live with 40 families:
- CRI Assessment Engine with MD review
- KBS Outcome Tracking (30/60/90 day)
- Full Omaha ↔ ICD-10 Crosswalk Engine (5-step pipeline)
- Worker-Owner Portal
- LMN generation + DocuSign + Marketplace
- Comfort Card reconciliation
- Wearable Integration (Apple Health)
- Employer Dashboard
- Admin Dashboard

## Phase 3 (Build After Phase 2)

- BCH Epic HL7 FHIR integration
- Predictive hospitalization ML
- PACE data exchange
- Federation multi-tenancy
